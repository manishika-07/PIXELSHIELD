# main.py — PhotoShield FastAPI backend
# Run with: uvicorn main:app --reload
import json
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles

import db
import shield as sh

# ── App setup ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="PhotoShield API",
    description="Women's-safety image protection backend. All images processed in memory.",
    version="1.0.0",
)

# Allow any origin so the frontend works from file:// and localhost
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Sha256", "X-Phash", "X-Protections-Applied"],
)

# Load response kit once at startup
RESPONSE_KIT_PATH = Path(__file__).parent / "response_kit.json"
with open(RESPONSE_KIT_PATH, encoding="utf-8") as f:
    # response_kit.json is plain, valid JSON (no comments), so load it directly.
    RESPONSE_KIT: dict = json.load(f)

VALID_PLATFORMS = set(RESPONSE_KIT.keys())
VALID_INCIDENT_STATUSES = {"open", "reported", "resolved"}
VALID_STRENGTHS = {"low", "medium", "high"}


@app.on_event("startup")
def startup():
    """Create DB tables if they don't exist."""
    db.init_db()


# ── Helpers ──────────────────────────────────────────────────────────────────

def require_client(x_client_id: str | None) -> str:
    """Validate X-Client-Id header; raise 400 if missing."""
    if not x_client_id or not x_client_id.strip():
        raise HTTPException(status_code=400, detail="X-Client-Id header is required.")
    return x_client_id.strip()


async def read_upload(file: UploadFile) -> bytes:
    """Read uploaded file bytes; raise 413 if over 10 MB."""
    data = await file.read()
    if len(data) > sh.MAX_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large ({len(data)//1024} KB). Maximum is 10 MB."
        )
    return data


def shield_error(exc: sh.ValidationError) -> HTTPException:
    return HTTPException(status_code=exc.status_code, detail=str(exc))


# ════════════════════════════════════════════════════════════════════════════
# PHASE 1 — Protect a photo
# ════════════════════════════════════════════════════════════════════════════

@app.post("/api/protect", summary="Protect an image (strip EXIF, shield, watermark)")
async def protect(
    image: Annotated[UploadFile, File(description="JPEG, PNG, or WEBP. Max 10 MB.")],
    strip_metadata: Annotated[bool, Form()] = True,
    shield_strength: Annotated[str, Form()] = "medium",
    watermark_text: Annotated[str, Form()] = "",
    x_client_id: Annotated[str | None, Header()] = None,
):
    """
    Full protection pipeline. Returns the processed PNG as a binary response.
    Headers: X-Sha256, X-Phash, X-Protections-Applied.
    """
    client_id = require_client(x_client_id)

    if shield_strength not in VALID_STRENGTHS:
        raise HTTPException(
            status_code=400,
            detail=f"shield_strength must be one of: {', '.join(VALID_STRENGTHS)}"
        )

    data = await read_upload(image)

    try:
        result = sh.protect_image(
            data,
            strip_metadata=strip_metadata,
            shield_strength=shield_strength,
            watermark_text=watermark_text,
        )
    except sh.ValidationError as exc:
        raise shield_error(exc)

    # Increment counter in DB
    with db.get_db() as conn:
        db.increment_reencoded(conn, client_id)

    return Response(
        content=result.png_bytes,
        media_type="image/png",
        headers={
            "X-Sha256": result.sha256,
            "X-Phash": result.phash,
            "X-Protections-Applied": ",".join(result.protections),
            "Content-Disposition": "attachment; filename=protected.png",
        },
    )


@app.post("/api/scan-metadata", summary="Scan image metadata (EXIF, GPS, device info)")
async def scan_metadata(
    image: Annotated[UploadFile, File(description="JPEG, PNG, or WEBP. Max 10 MB.")],
):
    """
    Returns EXIF fields found in the image — no data is stored.
    Useful to show users what their photo reveals before sharing.
    """
    data = await read_upload(image)
    try:
        result = sh.scan_metadata(data)
    except sh.ValidationError as exc:
        raise shield_error(exc)
    return result


# ════════════════════════════════════════════════════════════════════════════
# PHASE 2 — Watch & Fingerprints
# ════════════════════════════════════════════════════════════════════════════

@app.post("/api/fingerprints", summary="Register a fingerprint for an image")
async def add_fingerprint(
    image: Annotated[UploadFile, File()],
    label: Annotated[str, Form(description="Human-readable label, e.g. 'Profile pic Jan 2025'")],
    x_client_id: Annotated[str | None, Header()] = None,
):
    """
    Compute SHA-256 + pHash + dHash and store them (not the image).
    Returns the stored fingerprint record.
    """
    client_id = require_client(x_client_id)
    if not label.strip():
        raise HTTPException(status_code=400, detail="label must not be empty.")

    data = await read_upload(image)
    try:
        hashes = sh.compute_hashes(data)
    except sh.ValidationError as exc:
        raise shield_error(exc)

    with db.get_db() as conn:
        record = db.insert_fingerprint(
            conn, client_id, label.strip(),
            hashes.sha256, hashes.phash, hashes.dhash,
        )
    return record


@app.get("/api/fingerprints", summary="List all stored fingerprints")
def list_fingerprints(x_client_id: Annotated[str | None, Header()] = None):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        return db.list_fingerprints(conn, client_id)


@app.delete("/api/fingerprints/{fp_id}", summary="Delete a fingerprint by ID")
def delete_fingerprint(
    fp_id: int,
    x_client_id: Annotated[str | None, Header()] = None,
):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        deleted = db.delete_fingerprint(conn, client_id, fp_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Fingerprint {fp_id} not found.")
    return {"deleted": True, "id": fp_id}


@app.post("/api/fingerprints/compare", summary="Compare an image against stored fingerprints")
async def compare_fingerprint(
    image: Annotated[UploadFile, File()],
    x_client_id: Annotated[str | None, Header()] = None,
):
    """
    Returns the best match from stored fingerprints.
    Hamming distance ≤ 10 is treated as a likely match (resized/cropped/recompressed).
    """
    client_id = require_client(x_client_id)
    data = await read_upload(image)
    try:
        hashes = sh.compute_hashes(data)
    except sh.ValidationError as exc:
        raise shield_error(exc)

    with db.get_db() as conn:
        stored = db.list_fingerprints(conn, client_id)

    result = sh.compare_hashes(hashes.sha256, hashes.phash, stored)
    return result


# ════════════════════════════════════════════════════════════════════════════
# PHASE 3 — Incidents & Response kit
# ════════════════════════════════════════════════════════════════════════════

@app.post("/api/incidents", summary="Create a new incident note", status_code=201)
def create_incident(
    payload: dict,
    x_client_id: Annotated[str | None, Header()] = None,
):
    """
    Fields: platform (required), url, date_noticed, description, status.
    status must be one of: open, reported, resolved.
    """
    client_id = require_client(x_client_id)

    platform = payload.get("platform", "").strip()
    if not platform:
        raise HTTPException(status_code=400, detail="'platform' is required.")

    status = payload.get("status", "open").strip()
    if status not in VALID_INCIDENT_STATUSES:
        raise HTTPException(
            status_code=400,
            detail=f"status must be one of: {', '.join(VALID_INCIDENT_STATUSES)}"
        )

    with db.get_db() as conn:
        record = db.insert_incident(
            conn, client_id,
            platform=platform,
            url=payload.get("url", ""),
            date_noticed=payload.get("date_noticed", ""),
            description=payload.get("description", ""),
            status=status,
        )
    return record


@app.get("/api/incidents", summary="List all incidents")
def list_incidents(x_client_id: Annotated[str | None, Header()] = None):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        return db.list_incidents(conn, client_id)


@app.get("/api/incidents/{inc_id}", summary="Get a single incident")
def get_incident(inc_id: int, x_client_id: Annotated[str | None, Header()] = None):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        record = db.get_incident(conn, client_id, inc_id)
    if not record:
        raise HTTPException(status_code=404, detail=f"Incident {inc_id} not found.")
    return record


@app.patch("/api/incidents/{inc_id}", summary="Update an incident (partial update)")
def update_incident(
    inc_id: int,
    payload: dict,
    x_client_id: Annotated[str | None, Header()] = None,
):
    client_id = require_client(x_client_id)

    # Whitelist updatable fields
    allowed = {"platform", "url", "date_noticed", "description", "status"}
    updates = {k: v for k, v in payload.items() if k in allowed}

    if "status" in updates and updates["status"] not in VALID_INCIDENT_STATUSES:
        raise HTTPException(
            status_code=400,
            detail=f"status must be one of: {', '.join(VALID_INCIDENT_STATUSES)}"
        )

    with db.get_db() as conn:
        record = db.update_incident(conn, client_id, inc_id, **updates)
    if not record:
        raise HTTPException(status_code=404, detail=f"Incident {inc_id} not found.")
    return record


@app.delete("/api/incidents/{inc_id}", summary="Delete an incident")
def delete_incident(inc_id: int, x_client_id: Annotated[str | None, Header()] = None):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        deleted = db.delete_incident(conn, client_id, inc_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Incident {inc_id} not found.")
    return {"deleted": True, "id": inc_id}


@app.get("/api/response-kit", summary="Get platform-specific reporting guide")
def response_kit(platform: str = "other"):
    """
    Returns step-by-step reporting steps, takedown template, links, and helplines
    for the given platform. All legal/helpline entries are marked verify_before_launch.
    """
    platform = platform.lower().strip()
    if platform not in VALID_PLATFORMS:
        raise HTTPException(
            status_code=400,
            detail=f"platform must be one of: {', '.join(sorted(VALID_PLATFORMS))}"
        )
    return RESPONSE_KIT[platform]


# ════════════════════════════════════════════════════════════════════════════
# PHASE 4 — Overview & Checklist
# ════════════════════════════════════════════════════════════════════════════

@app.get("/api/stats", summary="Get usage stats for the current client")
def stats(x_client_id: Annotated[str | None, Header()] = None):
    """Returns: reencoded_copies, fingerprints, incident_notes."""
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        return db.get_stats(conn, client_id)


@app.get("/api/checklist", summary="Get 'Before you post' checklist state")
def get_checklist(x_client_id: Annotated[str | None, Header()] = None):
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        return db.get_checklist(conn, client_id)


@app.put("/api/checklist", summary="Update 'Before you post' checklist state")
def put_checklist(
    payload: dict,
    x_client_id: Annotated[str | None, Header()] = None,
):
    """
    Body: {"metadata_stripped": bool, "watermark_added": bool, "shield_applied": bool}
    Missing keys default to false.
    """
    client_id = require_client(x_client_id)
    with db.get_db() as conn:
        return db.set_checklist(
            conn, client_id,
            metadata_stripped=bool(payload.get("metadata_stripped", False)),
            watermark_added=bool(payload.get("watermark_added", False)),
            shield_applied=bool(payload.get("shield_applied", False)),
        )


# ── Static files (frontend) — MUST be last so API routes take priority ───────
FRONTEND_DIR = Path(__file__).parent / "frontend"
app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
