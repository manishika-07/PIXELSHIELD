# shield.py — All image processing logic. Images are NEVER written to disk.
import hashlib
import io
import random
from typing import NamedTuple

import imagehash
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ── Constants ────────────────────────────────────────────────────────────────

ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}  # as reported by Pillow
MAX_BYTES = 10 * 1024 * 1024  # 10 MB

# Noise amplitude per strength level (max delta per channel, 0-255 scale)
SHIELD_AMPLITUDE = {"low": 3, "medium": 4, "high": 6}

# Seed for the perturbation so it's deterministic per strength level
SHIELD_SEED = {"low": 42, "medium": 137, "high": 251}


# ── Validation ───────────────────────────────────────────────────────────────

class ValidationError(Exception):
    """Raised when an uploaded file fails validation."""
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.status_code = status_code


def load_and_validate(data: bytes) -> Image.Image:
    """
    Load image bytes with Pillow, validate format and size.
    Raises ValidationError with an appropriate HTTP status code.
    """
    if len(data) > MAX_BYTES:
        raise ValidationError(
            f"File too large ({len(data) // 1024} KB). Maximum allowed is 10 MB.",
            status_code=413,
        )
    try:
        img = Image.open(io.BytesIO(data))
        img.verify()                      # detects truncated / corrupt files
        img = Image.open(io.BytesIO(data))  # re-open after verify() (Pillow quirk)
    except Exception as exc:
        raise ValidationError(f"Cannot read image: {exc}")

    if img.format not in ALLOWED_FORMATS:
        raise ValidationError(
            f"Unsupported format '{img.format}'. Accepted: JPEG, PNG, WEBP."
        )
    return img


# ── Metadata scanner ─────────────────────────────────────────────────────────

def scan_metadata(data: bytes) -> dict:
    """
    Extract EXIF / metadata from image bytes.
    Returns {"found": [list of dicts], "has_gps": bool}.
    """
    img = load_and_validate(data)
    found = []
    has_gps = False

    exif_data = img._getexif() if hasattr(img, "_getexif") else None
    if not exif_data:
        return {"found": [], "has_gps": False}

    # Human-readable tag names from Pillow's TAGS dict
    from PIL.ExifTags import TAGS, GPSTAGS
    for tag_id, value in exif_data.items():
        tag_name = TAGS.get(tag_id, str(tag_id))

        # GPS block — decode sub-tags
        if tag_name == "GPSInfo":
            has_gps = True
            gps_decoded = {}
            if isinstance(value, dict):
                for gps_id, gps_val in value.items():
                    gps_decoded[GPSTAGS.get(gps_id, str(gps_id))] = str(gps_val)
            found.append({"field": "GPSInfo", "value": gps_decoded})
            continue

        # Keep only the fields that are interesting for a user warning
        INTERESTING = {"Make", "Model", "Software", "DateTime", "DateTimeOriginal",
                       "DateTimeDigitized", "Artist", "Copyright", "ImageDescription",
                       "UserComment", "HostComputer", "CameraOwnerName", "LensModel"}
        if tag_name in INTERESTING:
            found.append({"field": tag_name, "value": str(value)[:200]})

    return {"found": found, "has_gps": has_gps}


# ── Shield pipeline ──────────────────────────────────────────────────────────

class ShieldResult(NamedTuple):
    png_bytes: bytes
    sha256: str
    phash: str
    protections: list[str]  # labels of what was actually applied


def apply_shield(img: Image.Image, strength: str) -> Image.Image:
    """
    Add a seeded, low-amplitude high-frequency noise perturbation.
    The image looks unchanged to humans; the pixel values shift by at most
    SHIELD_AMPLITUDE[strength] counts per channel.

    This function is intentionally isolated so a stronger adversarial
    perturbation method (e.g., FGSM-style) can be swapped in later.
    """
    amplitude = SHIELD_AMPLITUDE.get(strength, SHIELD_AMPLITUDE["medium"])
    seed = SHIELD_SEED.get(strength, SHIELD_SEED["medium"])

    arr = np.array(img.convert("RGB"), dtype=np.int16)
    rng = np.random.default_rng(seed)

    # High-frequency pattern: random ±amplitude noise
    noise = rng.integers(-amplitude, amplitude + 1, size=arr.shape, dtype=np.int16)
    arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
    return Image.fromarray(arr)


def add_watermark(img: Image.Image, text: str) -> Image.Image:
    """
    Tile a faint visible watermark across the image.
    Keeps the image looking clean while asserting ownership.
    """
    if not text.strip():
        return img

    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    # Use default font; a real app could load a TTF here
    try:
        font = ImageFont.truetype("arial.ttf", size=max(14, img.width // 40))
    except Exception:
        font = ImageFont.load_default()

    # Measure text with textbbox (Pillow ≥ 9.2)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    step_x = tw + 60
    step_y = th + 40

    # Tile diagonally
    for y in range(-step_y, img.height + step_y, step_y):
        for x in range(-step_x, img.width + step_x, step_x):
            draw.text((x, y), text, fill=(255, 255, 255, 60), font=font)

    base = img.convert("RGBA")
    combined = Image.alpha_composite(base, overlay)
    return combined.convert("RGB")


def protect_image(
    data: bytes,
    strip_metadata: bool = True,
    shield_strength: str = "medium",
    watermark_text: str = "",
) -> ShieldResult:
    """
    Full protection pipeline:
      1. Validate & load
      2. Strip metadata (always re-encode into fresh RGB pixels)
      3. Apply shield noise
      4. Add watermark (if requested)
      5. Return PNG bytes + hashes + protection list
    """
    img = load_and_validate(data)
    protections: list[str] = []

    # Step 1: Strip metadata by converting pixels into a brand-new image.
    # We ALWAYS do this — the "strip_metadata" flag just controls the label.
    img = img.convert("RGB")  # drops EXIF; flattens palette / alpha
    fresh = Image.new("RGB", img.size)
    fresh.paste(img)
    img = fresh
    if strip_metadata:
        protections.append("metadata_stripped")

    # Step 2: Shield (noise perturbation)
    if shield_strength in SHIELD_AMPLITUDE:
        img = apply_shield(img, shield_strength)
        protections.append(f"shield_{shield_strength}")
    else:
        # Unknown strength → skip shield, don't silently apply wrong level
        pass

    # Step 3: Watermark
    if watermark_text.strip():
        img = add_watermark(img, watermark_text)
        protections.append("watermark")

    # Encode to PNG bytes in memory — never touches disk
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=False)
    png_bytes = buf.getvalue()

    # Compute hashes on the final bytes
    sha = hashlib.sha256(png_bytes).hexdigest()
    ph = str(imagehash.phash(img))

    return ShieldResult(
        png_bytes=png_bytes,
        sha256=sha,
        phash=ph,
        protections=protections,
    )


# ── Fingerprint hashes ───────────────────────────────────────────────────────

class FingerprintHashes(NamedTuple):
    sha256: str
    phash: str
    dhash: str


def compute_hashes(data: bytes) -> FingerprintHashes:
    """Compute SHA-256, pHash, and dHash from image bytes."""
    img = load_and_validate(data)
    sha = hashlib.sha256(data).hexdigest()
    ph = str(imagehash.phash(img))
    dh = str(imagehash.dhash(img))
    return FingerprintHashes(sha256=sha, phash=ph, dhash=dh)


def compare_hashes(
    query_sha: str,
    query_phash: str,
    stored_records: list[dict],
) -> dict:
    """
    Compare query hashes against all stored fingerprints.
    Returns the best (lowest hamming distance) match.
    Treat hamming distance <= 10 as a likely match.
    """
    if not stored_records:
        return {"matched": False, "label": None, "exact_match": False,
                "hamming_distance": None, "similarity_percent": None}

    query_ph = imagehash.hex_to_hash(query_phash)
    best = None
    best_dist = 999

    for rec in stored_records:
        # Exact SHA-256 match
        exact = rec["sha256"] == query_sha
        # Perceptual distance
        try:
            dist = query_ph - imagehash.hex_to_hash(rec["phash"])
        except Exception:
            dist = 999

        if exact or dist < best_dist:
            best_dist = dist
            best = rec
            if exact:
                break  # can't do better

    if best is None:
        return {"matched": False, "label": None, "exact_match": False,
                "hamming_distance": None, "similarity_percent": None}

    exact_match = best["sha256"] == query_sha
    # phash is 64 bits; similarity = (64 - dist) / 64 * 100
    similarity = max(0.0, round((64 - best_dist) / 64 * 100, 1))
    matched = exact_match or best_dist <= 10

    return {
        "matched":           matched,
        "label":             best["label"],
        "exact_match":       exact_match,
        "hamming_distance":  best_dist,
        "similarity_percent": similarity,
    }
