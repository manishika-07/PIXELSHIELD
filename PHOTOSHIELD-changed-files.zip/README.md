# PhotoShield Backend

Women's-safety image protection API — hackathon edition.
Built with FastAPI + SQLite. **Images are processed in memory and never stored.**

---

## Install

```bash
cd PHOTOSHIELD
pip install -r requirements.txt
```

---

## Run

```bash
uvicorn main:app --reload
```

Open **http://localhost:8000** → serves `frontend/index.html`  
Open **http://localhost:8000/docs** → interactive Swagger UI for every endpoint

---

## Project Layout

```
PHOTOSHIELD/
├── main.py              ← FastAPI app + all routes
├── shield.py            ← Image processing (validate, strip EXIF, shield, watermark, hash)
├── db.py                ← SQLite helpers (no ORM)
├── response_kit.json    ← Platform reporting guides
├── requirements.txt
├── test_api.py          ← Smoke test suite
├── README.md
├── API.md               ← Full endpoint reference for frontend wiring
└── frontend/
    ├── index.html       ← Full PhotoShield UI (wired to every endpoint)
    └── api.js           ← All fetch helpers + graceful fallback
```

---

## Curl Examples — one per endpoint

Replace `YOUR_CLIENT_ID` with any string (the frontend auto-generates one and stores it in localStorage).

### Phase 1 — Protect a photo

```bash
# Protect: strip EXIF + medium shield + watermark → returns PNG binary
curl -X POST http://localhost:8000/api/protect \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -F "image=@photo.jpg" \
  -F "strip_metadata=true" \
  -F "shield_strength=medium" \
  -F "watermark_text=PhotoShield" \
  --output protected.png \
  -D -   # print response headers (look for X-Protections-Applied)

# Scan metadata: see what EXIF data a photo contains (nothing stored)
curl -X POST http://localhost:8000/api/scan-metadata \
  -F "image=@photo.jpg"
```

### Phase 2 — Watch & Fingerprints

```bash
# Register a fingerprint (hashes only, not the image)
curl -X POST http://localhost:8000/api/fingerprints \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -F "image=@photo.jpg" \
  -F "label=My profile pic Jan 2025"

# List fingerprints
curl http://localhost:8000/api/fingerprints \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Delete fingerprint by ID
curl -X DELETE http://localhost:8000/api/fingerprints/1 \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Compare an image against stored fingerprints
curl -X POST http://localhost:8000/api/fingerprints/compare \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -F "image=@suspect.jpg"
```

### Phase 3 — Incidents & Response Kit

```bash
# Create incident note
curl -X POST http://localhost:8000/api/incidents \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -H "Content-Type: application/json" \
  -d '{"platform":"instagram","url":"https://instagram.com/p/abc","date_noticed":"2025-01-15","description":"Photo shared without consent","status":"open"}'

# List incidents
curl http://localhost:8000/api/incidents \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Get single incident
curl http://localhost:8000/api/incidents/1 \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Update incident status
curl -X PATCH http://localhost:8000/api/incidents/1 \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -H "Content-Type: application/json" \
  -d '{"status":"reported"}'

# Delete incident
curl -X DELETE http://localhost:8000/api/incidents/1 \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Get response kit for a platform
curl "http://localhost:8000/api/response-kit?platform=instagram"
# platforms: instagram | facebook | x | whatsapp | other
```

### Phase 4 — Overview & Checklist

```bash
# Stats
curl http://localhost:8000/api/stats \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Get checklist
curl http://localhost:8000/api/checklist \
  -H "X-Client-Id: YOUR_CLIENT_ID"

# Update checklist
curl -X PUT http://localhost:8000/api/checklist \
  -H "X-Client-Id: YOUR_CLIENT_ID" \
  -H "Content-Type: application/json" \
  -d '{"metadata_stripped":true,"watermark_added":true,"shield_applied":false}'
```

---

## Run Tests

```bash
# Terminal 1
uvicorn main:app --reload

# Terminal 2
python test_api.py
```

---

## Privacy Notes

- **Images are never written to disk or stored in the DB.**
- Only hashes (SHA-256, pHash, dHash), labels, notes, and counters are persisted.
- The database file `photoshield.db` is created automatically in the project folder.
- All data is scoped by `X-Client-Id`; there is no authentication.

---

## Wiring the Real Frontend

1. Copy your `index.html` into the `frontend/` folder.
2. Add before `</body>`:
   ```html
   <script src="api.js"></script>
   ```
3. See `API.md` for the full request/response reference per endpoint.
4. Every `api.js` function returns `{ok, data, error, headers}` — check `ok` before using `data`.
5. If the backend is unreachable, `ok` is `false` and the UI should fall back to its local behaviour.
