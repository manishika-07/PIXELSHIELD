/**
 * api.js — PhotoShield frontend API helpers
 * Drop this file in the same folder as index.html and add:
 *   <script src="api.js"></script>  before </body>
 *
 * Every helper returns a Promise<{ok: boolean, data: any, error: string|null}>.
 * If the backend is unreachable the promise resolves with ok=false and a
 * human-readable error — the UI should fall back to its local-only behaviour.
 */

// ── Client identity ──────────────────────────────────────────────────────────

/**
 * Returns a stable random client ID, persisted in localStorage.
 * The backend scopes all data to this ID (no authentication needed).
 */
function getClientId() {
  let id = localStorage.getItem("photoshield_client_id");
  if (!id) {
    // Generate a random 128-bit hex string
    id = Array.from(crypto.getRandomValues(new Uint8Array(16)))
              .map(b => b.toString(16).padStart(2, "0"))
              .join("");
    localStorage.setItem("photoshield_client_id", id);
  }
  return id;
}

const CLIENT_ID = getClientId();

// ── Core fetch wrapper ───────────────────────────────────────────────────────

// When served by the backend (http://localhost:8000/) use same-origin requests so any
// host/port works. Only fall back to localhost:8000 if the page is opened as a file://.
const BASE_URL = window.location.protocol === "file:" ? "http://localhost:8000" : "";

/**
 * Internal helper. Wraps fetch with X-Client-Id and graceful fallback.
 * @param {string} path       - e.g. "/api/stats"
 * @param {RequestInit} opts  - standard fetch options
 * @param {boolean} addClientId - whether to add X-Client-Id header
 * @returns {Promise<{ok: boolean, data: any, error: string|null, headers: Headers|null}>}
 */
async function _api(path, opts = {}, addClientId = true) {
  const headers = new Headers(opts.headers || {});
  if (addClientId) headers.set("X-Client-Id", CLIENT_ID);

  try {
    const res = await fetch(`${BASE_URL}${path}`, { ...opts, headers });
    const contentType = res.headers.get("content-type") || "";

    // Binary response (protected image)
    if (contentType.includes("image/")) {
      const blob = await res.blob();
      return {
        ok: res.ok,
        data: blob,
        error: res.ok ? null : `Server error ${res.status}`,
        headers: res.headers,
      };
    }

    // JSON response
    let data = null;
    try { data = await res.json(); } catch (_) {}
    return {
      ok: res.ok,
      data,
      error: res.ok ? null : (data?.detail || `Server error ${res.status}`),
      headers: res.headers,
    };
  } catch (err) {
    // Backend unreachable — fail gracefully
    console.warn("[PhotoShield] Backend unreachable:", err.message);
    return { ok: false, data: null, error: "Backend unreachable. Using local mode.", headers: null };
  }
}

// ════════════════════════════════════════════════════════════════════════════
// PHASE 1 — Protect a photo
// ════════════════════════════════════════════════════════════════════════════

/**
 * Protect an image: strip EXIF, apply shield noise, optionally watermark.
 * On success, data is a Blob (PNG) and headers contain X-Protections-Applied.
 *
 * @param {File} imageFile
 * @param {Object} options
 * @param {boolean} options.stripMetadata   default true
 * @param {"low"|"medium"|"high"} options.shieldStrength  default "medium"
 * @param {string} options.watermarkText    default ""
 * @returns {Promise<{ok, data: Blob|null, error, headers, protections: string[]}>}
 */
async function protectPhoto(imageFile, {
  stripMetadata = true,
  shieldStrength = "medium",
  watermarkText = "",
} = {}) {
  const form = new FormData();
  form.append("image", imageFile);
  form.append("strip_metadata", String(stripMetadata));
  form.append("shield_strength", shieldStrength);
  form.append("watermark_text", watermarkText);

  const result = await _api("/api/protect", { method: "POST", body: form });
  const protections = result.headers
    ? (result.headers.get("x-protections-applied") || "").split(",").filter(Boolean)
    : [];
  return { ...result, protections };
}

/**
 * Scan an image's metadata to show what it reveals (EXIF, GPS, device info).
 * Returns {found: Array, has_gps: boolean} — no data stored.
 *
 * @param {File} imageFile
 */
async function scanMetadata(imageFile) {
  const form = new FormData();
  form.append("image", imageFile);
  return _api("/api/scan-metadata", { method: "POST", body: form }, false);
}

// ════════════════════════════════════════════════════════════════════════════
// PHASE 2 — Watch & Fingerprints
// ════════════════════════════════════════════════════════════════════════════

/**
 * Register a perceptual fingerprint for an image.
 * Only hashes are stored — not the image itself.
 *
 * @param {File} imageFile
 * @param {string} label  Human-readable label (e.g. "Profile pic Jan 2025")
 */
async function addFingerprint(imageFile, label) {
  const form = new FormData();
  form.append("image", imageFile);
  form.append("label", label);
  return _api("/api/fingerprints", { method: "POST", body: form });
}

/**
 * List all stored fingerprints for this client.
 */
async function listFingerprints() {
  return _api("/api/fingerprints");
}

/**
 * Delete a fingerprint by its numeric ID.
 * @param {number} id
 */
async function deleteFingerprint(id) {
  return _api(`/api/fingerprints/${id}`, { method: "DELETE" });
}

/**
 * Compare an image against all stored fingerprints.
 * Returns {matched, label, exact_match, hamming_distance, similarity_percent}.
 *
 * @param {File} imageFile
 */
async function compareFingerprint(imageFile) {
  const form = new FormData();
  form.append("image", imageFile);
  return _api("/api/fingerprints/compare", { method: "POST", body: form });
}

// ════════════════════════════════════════════════════════════════════════════
// PHASE 3 — Incidents & Response Kit
// ════════════════════════════════════════════════════════════════════════════

/**
 * Create a new incident note.
 * @param {Object} incident
 * @param {string} incident.platform      Required
 * @param {string} incident.url
 * @param {string} incident.date_noticed
 * @param {string} incident.description
 * @param {"open"|"reported"|"resolved"} incident.status  default "open"
 */
async function createIncident(incident) {
  return _api("/api/incidents", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(incident),
  });
}

/**
 * List all incident notes for this client.
 */
async function listIncidents() {
  return _api("/api/incidents");
}

/**
 * Get a single incident by ID.
 * @param {number} id
 */
async function getIncident(id) {
  return _api(`/api/incidents/${id}`);
}

/**
 * Partially update an incident (PATCH).
 * @param {number} id
 * @param {Object} fields  Keys to update (platform, url, date_noticed, description, status)
 */
async function updateIncident(id, fields) {
  return _api(`/api/incidents/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(fields),
  });
}

/**
 * Delete an incident by ID.
 * @param {number} id
 */
async function deleteIncident(id) {
  return _api(`/api/incidents/${id}`, { method: "DELETE" });
}

/**
 * Get platform-specific reporting guide, takedown template, and helplines.
 * @param {"instagram"|"facebook"|"x"|"whatsapp"|"other"} platform
 */
async function getResponseKit(platform = "other") {
  return _api(`/api/response-kit?platform=${encodeURIComponent(platform)}`, {}, false);
}

// ════════════════════════════════════════════════════════════════════════════
// PHASE 4 — Overview & Checklist
// ════════════════════════════════════════════════════════════════════════════

/**
 * Get aggregate usage stats: {reencoded_copies, fingerprints, incident_notes}.
 */
async function getStats() {
  return _api("/api/stats");
}

/**
 * Get the "Before you post" checklist state.
 * Returns {metadata_stripped: bool, watermark_added: bool, shield_applied: bool}.
 */
async function getChecklist() {
  return _api("/api/checklist");
}

/**
 * Update the "Before you post" checklist.
 * @param {Object} state
 * @param {boolean} state.metadata_stripped
 * @param {boolean} state.watermark_added
 * @param {boolean} state.shield_applied
 */
async function setChecklist(state) {
  return _api("/api/checklist", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(state),
  });
}

// ── Exports (for use in ES-module setups or Node test runners) ───────────────
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    getClientId,
    protectPhoto, scanMetadata,
    addFingerprint, listFingerprints, deleteFingerprint, compareFingerprint,
    createIncident, listIncidents, getIncident, updateIncident, deleteIncident,
    getResponseKit,
    getStats, getChecklist, setChecklist,
  };
}
